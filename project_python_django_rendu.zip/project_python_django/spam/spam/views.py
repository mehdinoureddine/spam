from django.shortcuts import render

def home(request):
    return render(request,"home.html")
def pca(request):
    return render(request,"pca.html")
def svrandsvc(request):
    return render(request,"svrandsvc.html")
def knn(request):
    return render(request,"knn.html")

def randomforest(request):
    return render(request,"randomforest.html")
